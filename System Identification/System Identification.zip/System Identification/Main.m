%% 
% Master thesis project: Modelling respiratory mechanics 
% Author: Amne Mousa
% Date: 26-06-2020

% Script for system identification of measured mechanical ventilation data
% Estimation of Elastance and Resistance of the respiratory system 
% Estimation of seperate lung elastance and throacic elastance
%%
clear all
close all
clc 
%% 
load('P1.mat')
P1_results = Sys_Iden(P1);
%save('P1_results')

load('P2.mat')
P2_results = Sys_Iden(P2);
%save('P2_results')
 
load('P3.mat')
P3_results = Sys_Iden(P3);
%save('P3_results')

load('P4.mat')
P4_results = Sys_Iden(P4);
%save('P4_results')

load('P5.mat')
P5_results = Sys_Iden(P5);
%save('P5_results')
