function TF = TF_est(data1_train, data1_val)
tf = tfest(data1_train, 1, 0);          
TF.tf = tf;
cov  = getcov(tf); 
TF.Resistance =1/tf.Numerator;
TF.Elastance =tf.Denominator(2)*TF.Resistance;

TF.E_SE = (1/(sqrt(length(data1_train))))*sqrt(cov(1,1));
TF.R_SE = (1/(sqrt(length(data1_train))))*sqrt(cov(2,2));


[y, fit, x0] = compare(data1_val, tf);
TF.Fit = fit;
TF.MSE = goodnessOfFit(y.y, data1_val.y,'MSE');
end