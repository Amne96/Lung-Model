function P_results = Para_est(P)

%% These are the prepared data files 
data1 = iddata(P.Volume, P.P_aw, P.dt); data1.OutputName = 'Volume', data1.InputName = 'Airway Pressure'; 
data2 = iddata([P.Volume,P.Volume],[P.P_es, P.P_L], P.dt); data2.OutputName = {'Volume', 'Volume1'}, data2.InputName = {'Oesofageal Pressure', 'Transpulmonary Pressure'}
data3 = iddata(P.Volume, P.P_es, P.dt); data3.OutputName = 'Volume', data3.InputName = 'Oesophageal Pressure';
data4 = iddata(P.Volume, P.P_L, P.dt); data4.OutputName = 'Volume', data4.InputName = 'Transpulmonary Pressure';
figure() 
plot(data1), title ''
figure()
plot(data2), title ''
%% Analytical parameter estimation state space step response
%P_results.Manual = AnalyticalEstimation(P.Single.t, P.Single.V, P.Single.Y_ss);
%% Optimisation of analytical parameter estimation
%P_results.ManualOptimisation = Analytical_Optimisation(P.Single.Y_ss, P.Single.V, P.Single.t);
%% Black box state space estimation
%P_results.Blackbox = Blackbox(data1);
% n4sid not physiological parameters --> iterative algorithms do estimate
% accurately

%% Grey box estimations
P_results.RespiratorySystem = grey_est(data1);
P_results.Thorax = grey_est(data3);
P_results.Lung = grey_est(data4);

%% Estimating using transferfunction
P_results.TF = TF_est(data1);
%% Use of transferfunction 

% utrain=P_air(1:2100)-7;
% ytrain=V(1:2100);T
% train = iddata(ytrain,utrain, dt);  
% 
% uval=P_air(2101:end)-7;
% yval=V(2101:end);
% val= iddata(yval,uval, dt);  
% 
% % importeer train en val iddata objecten in ident tool, sleep "train-data" naar
% % working data vakje en sleep "val-data" naar Vaidation data vakje. We
% % gebruiken dus andere punten voor de validatie. Schat nu de transfer
% % functies (1 pool, 0 zeros en 2 polen, 1 zero).

%%
% tf2 = tfest(data1, 2,1);
% % bepalen fysiologische parameters uit transfer function tf2 (2 polen)
% b1=tf2.Numerator(1);
% b2=tf2.Numerator(2);
% a2=tf2.Denominator(2);
% a3=tf2.Denominator(3);
% 
% % stelsel van polynomen, volgorde van 4 onbekenden R1,R2,E1,E2
% polysys{1,1}=[b1,-1,-1];
% polysys{1,2}=[1 1 0 0;1 0 0 0;0 1 0 0];
% polysys{2,1}=[b2,-1,-1];
% polysys{2,2}=[1 1 0 0;0 0 1 0;0 0 0 1];
% polysys{3,1}=[1,1,-a2];
% polysys{3,2}=[0 1 1 0;1 0 0 1;1 1 0 0];
% polysys{4,1}=[a3,-1];
% polysys{4,2}=[1 1 0 0;0 0 1 1];
% 
% for i=2:7
%     dimNullSpace(i-1)=size(null(getM(polysys,7)),2);
% end
% % de dimensie van de nulruimte groeit uiteindelijk in stapjes van 2,
% % wanneer het stelsel van polynomen een eindig aantal oplossingen heeft dan
% % zou dit naar een constant geval moeten evolueren. Conclusie: er zijn
% % oneindig veel (R1,R2,E1,E2)-waarden die dezelfde transferfunctie
% % opleveren.

end