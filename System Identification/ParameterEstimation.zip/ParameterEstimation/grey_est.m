function Grey_SS = grey_est(data1);

E_min = 1 ;        % elastance compartment 1 [cm H2O/L]
E_max = 50 ;
R_min = 1 ;
R_max = 50 ;

% One compartment state space estimation

odefun = 'RespiratoryModel';
% Initial states
E = 1 ;
R = 1 ;
parameters = {'Elastance',E; 'Resistance',R};
fcn_type = 'c';
sys1 = idgrey(odefun, parameters, fcn_type);

sys1.Structure.Parameters(1).Free = true;
sys1.Structure.Parameters(2).Free = true;
sys1.Structure.Parameters(1).Maximum = E_max; 
sys1.Structure.Parameters(1).Minimum = E_min; 
sys1.Structure.Parameters(2).Maximum = R_max; 
sys1.Structure.Parameters(2).Minimum = R_min;

sys2 = greyest(data1,sys1);

para_est = getpvec(sys2) ;  
para_var = getcov(sys2);

Grey_SS.sys = sys2;
Grey_SS.Elastance = para_est(1);
Grey_SS.Resistance = para_est(2);
Grey_SS.cov = para_var;
Grey_SS.Fit = sys2.Report.Fit.FitPercent;
Grey_SS.MSE = sys2.Report.Fit.MSE;

end
