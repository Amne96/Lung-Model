function TF = TF_est(data1)
tf1 = tfest(data1, 2, 0);

TF.Cov  = getcov(tf1); 
TF.Resistance =1/tf1.Numerator;
TF.Elastance =tf1.Denominator(2)*TF.Resistance;
TF.Fit = tf1.Report.Fit.FitPercent;
TF.MSE = tf1.Report.Fit.MSE;
TF.tf = tf1;

end