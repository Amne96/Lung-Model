%% 
% Master thesis project: Modelling respiratory mechanics 
% Author: Amne Mousa
% Date: 24-06-2020
% ----------------- UNFINISHED SCRIPTS!!! ---------------------

% Script for system identification of measured mechanical ventilation data
% Estimation of Elastance and Resistance of the respiratory system 
% Estimation of seperate lung elastance and throacic elastance
%%
clear all
close all
clc 
%%
load('P1.mat')
P1_results = Para_est(P1);
%save('P1_results')

load('P2.mat')
P2_results = Para_est(P2);
%save('P2_results')
 
load('P3.mat')
P3_results = Para_est(P3);
%save('P3_results')

load('P4.mat')
P4_results = Para_est(P4);
%save('P4_results')

load('P5.mat')
P5_results = Para_est(P5);
%save('P5_results')
